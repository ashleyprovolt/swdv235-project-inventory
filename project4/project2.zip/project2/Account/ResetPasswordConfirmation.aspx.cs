﻿using System.Web.UI;

namespace project2.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}